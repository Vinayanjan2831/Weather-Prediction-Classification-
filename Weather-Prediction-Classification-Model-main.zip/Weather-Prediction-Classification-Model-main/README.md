# Weather-Prediction-Classification-Model
This repository contains datasets and python code for weather prediction classification machine learning model

# Datasets
This model will be using two datasets namely, Summary of Weather and Weather Station Locations.
![Screenshot (693)](https://user-images.githubusercontent.com/54886674/115746950-6e99a000-a3b2-11eb-9ee5-8fcc6e57764a.png)
![Screenshot (692)](https://user-images.githubusercontent.com/54886674/115747192-a0126b80-a3b2-11eb-8a38-c59d0b6d8f45.png)




# Machine Learning Model
This dataset will be evaluated on two classification model namely, Linear and Naive Bayes.
![Screenshot (695)](https://user-images.githubusercontent.com/54886674/115747188-a0126b80-a3b2-11eb-93aa-8b6a8612b09d.png)
![Screenshot (694)](https://user-images.githubusercontent.com/54886674/115747191-a0126b80-a3b2-11eb-92b4-ae12ad6e8791.png)
![Screenshot (696)](https://user-images.githubusercontent.com/54886674/115747189-a0126b80-a3b2-11eb-86b3-0d329c9fc0b6.png)
![Screenshot (697)](https://user-images.githubusercontent.com/54886674/115747190-a0126b80-a3b2-11eb-85fa-43c3a2ea5ae5.png)
![Screenshot (698)](https://user-images.githubusercontent.com/54886674/115747193-a0126b80-a3b2-11eb-8aae-52b67bef20a6.png)
![Screenshot (699)](https://user-images.githubusercontent.com/54886674/115747203-a1dc2f00-a3b2-11eb-8213-d4a72c72c2d3.png)

